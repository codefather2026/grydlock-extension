"use strict";
(() => {
  // src/intercept/protocol.ts
  var WINDOW_REQUEST_TYPE = "GRYDLOCK_REQUEST_OUTCOME";
  var WINDOW_RESPONSE_TYPE = "GRYDLOCK_OUTCOME_RESPONSE";

  // src/intercept/mainWorldEntry.ts
  var FREIGHTER_REQUEST_SOURCE = "FREIGHTER_EXTERNAL_MSG_REQUEST";
  var FREIGHTER_RESPONSE_SOURCE = "FREIGHTER_EXTERNAL_MSG_RESPONSE";
  var SUBMIT_TRANSACTION_TYPE = "SUBMIT_TRANSACTION";
  function requestOutcome(xdr) {
    const requestId = crypto.randomUUID();
    return new Promise((resolve) => {
      function onMessage(event) {
        if (event.source !== window) return;
        const data = event.data;
        if (data?.type !== WINDOW_RESPONSE_TYPE || data.requestId !== requestId) return;
        window.removeEventListener("message", onMessage);
        const outcome = data.outcome;
        resolve(outcome === "proceed" || outcome === "allow" ? outcome : "cancel");
      }
      window.addEventListener("message", onMessage);
      window.postMessage({ type: WINDOW_REQUEST_TYPE, requestId, xdr }, "*");
    });
  }
  window.addEventListener(
    "message",
    (event) => {
      if (event.source !== window) return;
      const data = event.data;
      if (data?.source !== FREIGHTER_REQUEST_SOURCE || data.type !== SUBMIT_TRANSACTION_TYPE || data.__grydlockReviewed || typeof data.transactionXdr !== "string" || typeof data.messageId !== "number") {
        return;
      }
      event.stopImmediatePropagation();
      const request = data;
      requestOutcome(request.transactionXdr).then((outcome) => {
        if (outcome === "cancel") {
          window.postMessage(
            {
              source: FREIGHTER_RESPONSE_SOURCE,
              messagedId: request.messageId,
              signedTransaction: "",
              signerAddress: "",
              apiError: {
                code: -4,
                message: "Rejected by Gryd Lock: user cancelled after reviewing the risk warning."
              }
            },
            window.location.origin
          );
          return;
        }
        window.postMessage({ ...request, __grydlockReviewed: true }, window.location.origin);
      });
    },
    true
  );
})();
//# sourceMappingURL=mainWorld.js.map
