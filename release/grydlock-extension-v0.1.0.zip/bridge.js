"use strict";
(() => {
  // src/intercept/protocol.ts
  var WINDOW_REQUEST_TYPE = "GRYDLOCK_REQUEST_OUTCOME";
  var WINDOW_RESPONSE_TYPE = "GRYDLOCK_OUTCOME_RESPONSE";

  // src/intercept/bridgeEntry.ts
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (data?.type !== WINDOW_REQUEST_TYPE || !data.requestId || !data.xdr) return;
    const message = {
      type: "SIGN_REQUEST",
      requestId: data.requestId,
      xdr: data.xdr
    };
    chrome.runtime.sendMessage(message, (response) => {
      window.postMessage(
        { type: WINDOW_RESPONSE_TYPE, requestId: data.requestId, outcome: response?.outcome ?? "cancel" },
        "*"
      );
    });
  });
})();
//# sourceMappingURL=bridge.js.map
